from asammdf import MDF
import json,os,time,sys
import numpy as np
import pandas as pd
import plotly.graph_objs as go
import plotly.offline as pltoff
from plotly.subplots import make_subplots
from plotly.graph_objs import Scatter,Layout

# MF4文件开启
class openMDF:
    def __init__(self, path):
        self.open_file(path)

    def open_file(self, path):
        print('开启mf4文件')
        self.mf = MDF(path)
    def close_file(self):
        print('关闭mf4文件')
        self.mf.close()
    # 0
    def task_0(self):
        try:
            odometer = self.mf.get('ICM_TotalOdometer')
        except:
            pass
        else:
            return odometer
    
    # 1
    def task_1(self):
        signal_left = 'BSDS_LCAWarnLeft'
        signal_right = 'BSDM_LCAWarnRight'
        signal_LCASt = 'BSDM_LCASt'
        if self.mf:
            try:
                left = self.mf.get(signal_left)
                right = self.mf.get(signal_right)
                LCASt = self.mf.get(signal_LCASt)
                odometer = self.task_0()
            except:
                return False
            else:
                self.close_file()
    
    # 19
    def task_19(self):
        signal = 'IFC_LKS_St'
        if self.mf:
            try:
                data = self.mf.get(signal)
                odometer = self.task_0()
            except:
                return False
            else:
                data_list = {'data': {'samples': [], 'timestamps': []},'odometer': {'samples': [], 'timestamps': []}}
                for run_type in data.samples.tolist():
                    if run_type == b'LKS off':
                        data_list['data']['samples'].append(-1)
                    elif run_type == b'LKS active':
                        data_list['data']['samples'].append(1)
                    else:
                        data_list['data']['samples'].append(0)
                for run_time in data.timestamps.tolist():
                    data_list['data']['timestamps'].append(run_time - data.timestamps.tolist()[0])
                data_list['odometer']['samples'] = odometer.samples.tolist()
                for odo_time in odometer.timestamps.tolist():
                    data_list['odometer']['timestamps'].append(odo_time - odometer.timestamps.tolist()[0])
                self.close_file()
                return data_list

class CreatePlot:
    def __init__(self):
        self.create_subplots()
    # 初始化画布
    def create_subplots(self):
        self.fig = make_subplots(
                rows=3,
                cols=1,
                subplot_titles=[])
    # 19
    def get_data_19(self,data):
        trace1_data = []
        trace2_data = []
        trace3_data = []
        
        keys_list = []
        def func(hpa_real):
            ec_hpa_df = pd.Series(file_odometer['timestamps'])
            range_max = ec_hpa_df[ec_hpa_df >= hpa_real].min()
            range_min = ec_hpa_df[ec_hpa_df <= hpa_real].max()
            # 判断更接近哪一个
            if abs(range_max-hpa_real) < abs(range_min - hpa_real):
                    return range_max
            else:
                    return range_min
        for key in data.keys():
            file_data = data[key]['data']
            # 功能关闭的时间
            off_times = 0
            # 功能开启的时间
            open_times = 0
            temp = []
            split_list_samples = []
            split_list_timestamps = []
            # 存储变动下标
            for i in range(len(file_data['samples'])):
                if i < len(file_data['samples'])-1:
                    if file_data['samples'][i] != file_data['samples'][i+1]:
                        temp.append(i+1)
            temp.append(len(file_data['samples']))
            # 对功能状态进行分割
            for j in range(len(temp)):
                if j == 0:
                    split_list_samples.append(file_data['samples'][:temp[j]])
                    split_list_timestamps.append(file_data['timestamps'][:temp[j]])
                else:
                    split_list_samples.append(file_data['samples'][temp[j-1]:temp[j]])
                    split_list_timestamps.append(file_data['timestamps'][temp[j-1]:temp[j]])
            war_times = []
            # 计算各种功能对应的持续时间
            for timestam in split_list_timestamps:
                try:
                    war_times.append(timestam[-1]-timestam[0])
                except IndexError as e:
                    war_times.append(0)
            # 分割出功能开启时间和关闭时间
            for index in range(len(war_times)):
                if 1 in split_list_samples[index]:
                    open_times += war_times[index]
                if -1 in split_list_samples[index]:
                    off_times += war_times[index]
            # 功能关闭时间和开启时间的数据汇总
            off_on_list = [off_times, open_times]
            # 功能激活次数计算
            sum_1 = 0
            for index,value in enumerate(file_data['samples']):
                if index < len(file_data['samples'])-1 and value == -1 and file_data['samples'][index+1] == 1:
                    sum_1 += 1
            
            # self.plot_append(key, file_data, 1)
            file_odometer = data[key]['odometer']
            # 车辆运行时间
            run_time = file_odometer['timestamps'][-1] - file_odometer['timestamps'][0]
            # 车辆总行驶里程
            run_odometer = file_odometer['samples'][-1] - file_odometer['samples'][0]
            # 将  车辆运行时间， 功能激活次数，车辆总行驶里程 汇总
            time_odometer_active = [sum_1, run_time, run_odometer]

            # 功能激活时行驶的总里程
            open_odometer = []
            odometer_times = []
            # 通过之前的分割获取时间戳
            for index in range(len(split_list_samples)):
                if 1 in split_list_samples[index]:
                    odometer_times.append([split_list_timestamps[index][0],split_list_timestamps[index][-1]])
            # 通过断电时间戳获取里程信息
            for index in odometer_times:
                open_odometer.append(file_odometer['samples'][file_odometer['timestamps'].index(func(index[1]))] - file_odometer['samples'][file_odometer['timestamps'].index(func(index[0]))])
            trace1_data.append(time_odometer_active)
            trace2_data.append(off_on_list)
            trace3_data.append(sum(open_odometer) if open_odometer != [] else 0)
            keys_list.append(key)
        # 数据形态转化
        # 进行数据转置
        trace1_data = np.array(trace1_data).T.tolist()
        trace2_data = np.array(trace2_data).T.tolist()
        trace3_data = np.array(trace3_data).T.tolist()
        print(trace3_data)
        # 开始绘图1
        names = ['功能激活次数', '车辆运行时间', '车辆行驶里程数']
        self.plot_append(names,keys_list, trace1_data, 1)
        # 开始绘图2
        names = ['功能关闭的时间', '功能开启的时间']
        self.plot_append(names,keys_list, trace2_data, 2)
        # 开始绘图3
        names = ['功能激活时的总行驶里程']
        self.plot_append_1(names,keys_list, trace3_data, 3)
        self.create_plot()
    # 构建图表对象
    def plot_append(self, file_names, keys_list, data, rows):
        for index in range(len(file_names)):
            trace = go.Bar(
                name=file_names[index],
                # fill='tozeroy',
                x=keys_list,
                y=data[index]
            )
            self.fig.append_trace(trace, rows, 1)
    # 一维数据添加
    def plot_append_1(self, file_names, keys_list, data, rows):
        trace = go.Bar(
            name=file_names[0],
            # fill='tozeroy',
            x=keys_list,
            y=data
        )
        self.fig.append_trace(trace, rows, 1)
    def create_plot(self):
        filename = input('请输入要生成的文件名(html格式)：')
        pltoff.plot(self.fig, filename=filename + '.html')

# 读取mf4文件路径， 可忽略  
def file_path_list(path):
    file_list = []
    for root,dirs,files in os.walk(path):
        for i in files:
            if i.endswith('MF4'):
                file_list.append(os.path.join(root,i))
    return file_list
if __name__ == "__main__":
    base_file_path = 'G:/loc/szh/DA/Driving/System_APP/02_GAC/01_A18/DASy/'
    file_list = file_path_list(base_file_path)
    all_data_list = {}
    i = 0
    # 读取mf4文件， 可忽略
    while i < 5:
        try:
            file_path = file_list.pop()
        except IndexError as e:
            break
        else:
            print(file_path)
            file_name = file_path.split('\\')[-1].split('.')[0]
            mf = openMDF(file_path)
            data_list = mf.task_19()
            all_data_list[file_name] = data_list
            print(len(all_data_list))
            print('文件：{}读取完毕， 数据存储完成，开始下一个文件'.format(file_name))
        i += 1
    # 传入数据进行绘图
    cp = CreatePlot()
    cp.get_data_19(all_data_list)